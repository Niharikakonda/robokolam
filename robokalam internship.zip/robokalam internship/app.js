function showMessage() {
    alert("Thank you for reaching out!");
}